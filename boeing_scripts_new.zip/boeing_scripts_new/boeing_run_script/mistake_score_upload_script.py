import json
import random
from raga import *
import pandas as pd
import datetime
from ragaai_models.labelling_quality import LabellingQualityChecks
from ragaai_models.embedding_generator import EmbeddingGenerator
import ast

def get_timestamp_x_hours_ago(hours):
    current_time = datetime.datetime.now()
    delta = datetime.timedelta(days=90, hours=hours)
    past_time = current_time - delta
    timestamp = int(past_time.timestamp())
    return timestamp


def img_url(x):
    return StringElement(
        x.replace(
            "s3://raga-engineering",
            "https://raga-engineering.s3.us-east-2.amazonaws.com",
        )
    )

def replace_recc(x):
    return x.replace("rrec/", "rrec__")

def annotation_v1(row):
    AnnotationsV1 = ImageDetectionObject()
    detection = json.loads(row["AnnotationsV1"].replace("'", '"'))
    # for detection in annotation_json.get("detections"):

    AnnotationsV1.add(
        ObjectDetection(
            Id=detection["Id"],
            ClassId=detection["ClassId"],
            ClassName=detection["ClassName"],
            Confidence=float(detection["Confidence"]),
            BBox=detection["BBox"],
            Format="xywh_normalized",
        )
    )
    return AnnotationsV1


def model_inferences(row):
    ModelInferences = ImageDetectionObject()
    model_inference_json = json.loads(row["ModelInferences"].replace("'", '"'))
    # for detection in model_inference_json.get("detections"):

    if type(model_inference_json) == type({}):
        model_inference_json = model_inference_json["annotation"]

    for idx, detection in enumerate(model_inference_json):
        ModelInferences.add(
            ObjectDetection(
                Id=idx,  # detection["Id"],
                ClassId=detection["ClassId"],
                ClassName=detection["ClassName"],
                Confidence=float(detection["confidence"]),
                BBox=detection["BBox"],
                Format="xywh_normalized",
            )
        )
    return ModelInferences


def imag_vectors_m1(row):
    emb_generator = EmbeddingGenerator()
    image_path = row['ImageUri']

    if image_path.startswith('s3://'):
        s3_client = boto3.client('s3')
        # Parse S3 URI
        parsed = urlparse(image_path)
        bucket = parsed.netloc
        key = parsed.path.lstrip('/')
        
        # Create temp directory and file
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(key)[1]) as temp_file:
            try:
                # Download file from S3
                s3_client.download_file(bucket, key, temp_file.name)
                # Generate embeddings from temp file
                embeddings_list = emb_generator.get_embeddings(temp_file.name)['embeddings']
            finally:
                # Clean up temp file
                if os.path.exists(temp_file.name):
                    os.unlink(temp_file.name)
    else:
        # Handle local file path
        embeddings_list = emb_generator.get_embeddings(image_path)['embeddings']
        
    ImageVectorsM1 = ImageEmbedding()
    for embedding in embeddings_list:
        ImageVectorsM1.add(Embedding(embedding))

    return ImageVectorsM1


def image_classification(x):
    classification = ImageClassificationElement()
    x = ast.literal_eval(x)
    for key, value in x.items():
        classification.add(key=key, value=value)
    return classification

def mistake_score(df):
    filepath =  df["ImageUri"].values.tolist()
    embedding = df["embedding"].apply(lambda x: ast.literal_eval(x)).values.tolist()
    label =  df['AnnotationsV1'].apply(lambda x: ast.literal_eval(x)['ClassName']).values.tolist()
    
    labelling_quality = LabellingQualityChecks(embedding, filepath, label)
    mistake_score = labelling_quality.calculate_mistake_score()
    
    mistake_score_column = MistakeScore()
    for x in mistake_score:
        for key, value in x.items():
            mistake_score_column.add(key=key, value=value, area=0)
    return mistake_score_column

def generate_random():
    classes = ["Yes", "No"]
    return random.choice(classes)


def csv_parser(csv_file):
    df = pd.read_csv(csv_file)
    data_frame = pd.DataFrame()
    data_frame["ImageId"] = df["ImageId"]
    data_frame["ImageUri"] = df["ImageUri"].apply(replace_recc).apply(lambda x: img_url(x))
    data_frame["TimeOfCapture"] = df.apply(
        lambda row: TimeStampElement(get_timestamp_x_hours_ago(row.name)), axis=1
    )
    data_frame["ImageVectorsM1"] = df['embedding'] = df.apply(imag_vectors_m1, axis=1)
    data_frame["AnnotationsV1"] = df.apply(annotation_v1, axis=1)
    data_frame['MistakeScore'] = mistake_score(df)
    
    return data_frame


csv_path = "datasets/OD_LQC.csv"
pd_data_frame = csv_parser(csv_path)
print("DF loaded")

schema = RagaSchema()
schema.add("ImageId", PredictionSchemaElement())
schema.add("ImageUri", ImageUriSchemaElement())
schema.add("TimeOfCapture", TimeOfCaptureSchemaElement())

schema.add("ImageVectorsM1", ImageEmbeddingSchemaElement(model="GT"))
schema.add("MistakeScore", MistakeScoreSchemaElement(ref_col_name="AnnotationsV1"))
schema.add("AnnotationsV1", InferenceSchemaElement(model="GT",label_mapping={"1":"signs"}))
# schema.add("ModelInferences", InferenceSchemaElement(model="ModelA"))

run_name = (
    f"BDD_v1-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
)
dataset_name = "bdd_val_5"

test_session = TestSession(
    project_name="testingProject",
    run_name=run_name,
    access_key="SS23s8JVCeyeJD0blVE5",
    secret_key="VWn0rhZVU9BtUAR4ueV0QIg750jkoGpUPgQ2Mf9c",
    host="https://prod5.ragaai.ai"
)


cred = DatasetCreds(region="us-east-2")

# create test_ds object of Dataset instance
test_ds = Dataset(
    test_session=test_session,
    name=dataset_name,
    type=DATASET_TYPE.IMAGE,
    data=pd_data_frame,
    schema=schema,
    creds=cred
)
print("Starting loading ds")
test_ds.load()