from raga import *
import datetime

def run(project_name, access_key, secret_key, host):
    run_name = f"FasterRCNN Tests"

    # create test_session object of TestSession instance
    test_session = TestSession(project_name=project_name, run_name= run_name, access_key=access_key, secret_key=secret_key, host=host)

    rules = IPDRules()
    rules.add(metric="image-property-suite")

    edge_case_detection = image_property_drift(test_session=test_session,
                                            reference_dataset_name="bdd_train_1",
                                            eval_dataset_name="bdd_val_1",
                                            rules=rules,
                                            test_name=f"Image-Property-Drift-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}",
                                            type="image-property-drift",
                                            output_type="image-data"
                                            )

    test_session.add(edge_case_detection)
    test_session.run()

